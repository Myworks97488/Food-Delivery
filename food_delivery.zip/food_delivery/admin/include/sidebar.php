<ul class="navbar-nav  sidebar sidebar-dark accordion" id="accordionSidebar" style="background-color: #e7272d!important;">

            <!-- Sidebar - Brand -->
            <a class="sidebar-brand d-flex align-items-center justify-content-center" href="index.html">
                <div class="sidebar-brand-icon rotate-n-35">
                    <i class="fas fa-laugh-wink"></i>
                </div>
                <div class="sidebar-brand-text mx-3">Food <sup>Plaza</sup></div>
            </a>

            <!-- Divider -->
            <hr class="sidebar-divider my-0">
            <!-- Nav Item - Dashboard -->
            <li class="nav-item active">
                <a class="nav-link" href="blank.php" style="color: #fff; ">
                    <img src="profile.png" alt="" style="width:20px; height:20px;" class="img"> 
                    <span style="font-size: 20px;">Dashboard</span></a>
            </li>

            <!-- Divider -->
            <hr class="sidebar-divider" >

            <!-- Heading -->
            <div class="sidebar-heading">
                Interface
            </div>

            <!-- Nav Item - Pages Collapse Menu -->
            <li class="nav-item">
                <a class="nav-link collapsed" href="index.php" style="color: #fff; " >
                    <i class="fas fa-fw fa-cog"></i>
                    <span><b style="font-size: 20px;">Add Products </b></span>
                </a>
              
            </li>

            <!-- Nav Item - Utilities Collapse Menu -->
            <li class="nav-item">
                <a class="nav-link collapsed" href="list.php" style="color: #fff; " >
                    <i class="fas fa-fw fa-wrench"></i>
                    <span><b style="font-size: 20px;" >Product List</b></span>
                </a>
            </li>

            <li class="nav-item">
                <a class="nav-link collapsed" href="food_orders.php" style="color: #fff; " >
                    <i class="fas fa-fw fa-wrench"></i>
                    <span><b style="font-size: 20px;" >List of Orders</b></span>
                </a>
            </li>

           
        </ul>