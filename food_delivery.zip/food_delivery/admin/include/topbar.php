<nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">

                    <!-- Sidebar Toggle (Topbar) -->
                    <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
                        <i class="fa fa-bars"></i>
                    </button>

                    <!-- Topbar Navbar -->
                    <ul class="navbar-nav ml-auto">

                        <!-- Nav Item - Search Dropdown (Visible Only XS) -->

                        <li style="margin-top:15px"><a href="logout.php" class="btn btn-danger">LOGOUT<i class="fa-solid fa-arrow-right-from-bracket" style="padding-left:20px"></i></a></li>



                        <div class="topbar-divider d-none d-sm-block"></div>


                    </ul>

                </nav>