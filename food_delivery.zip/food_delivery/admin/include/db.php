<?php 
$connection = mysqli_connect("localhost","root","","food_db");
?>